import os
import shutil
from datetime import datetime

# Folder to take a backup of (change this if needed)
source_folder = r"D:\D\5-11\Files"  # or use an absolute path like r"D:\D\5-11\Files\files"

# Where to store the backup
backup_folder = "backup"
os.makedirs(backup_folder, exist_ok=True)

# Generate timestamp
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# Construct the backup file name (without .zip extension — shutil adds it automatically)
backup_filename = os.path.join(backup_folder, f"backup_{timestamp}")

# Check if source folder exists before creating backup
if not os.path.exists(source_folder):
    print(f"Error: Source folder '{source_folder}' does not exist.")
    exit(1)

# Create a zip archive of the source folder
shutil.make_archive(backup_filename, 'zip', source_folder)

print(f"Backup created: {backup_filename}.zip")
