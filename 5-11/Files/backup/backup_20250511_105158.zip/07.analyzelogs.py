with open("app.log") as f:
    for line in f:
        if "ERROR" in line:
            print(line.strip())
        elif "WARNING" in line:
            print(line.strip())
        elif "CRITICAL" in line:
            print(line.strip())
        elif "INFO" in line:
            print(line.strip())
        elif "DEBUG" in line:
            print(line.strip())